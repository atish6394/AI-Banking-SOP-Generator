# Simulated sample processes

These are generic learning examples, not official bank policies.

## UPI payment failure
A customer reports a payment failure. Record the complaint, verify transaction details through authorized systems, follow the approved dispute process, escalate exceptions, and update the case.

## KYC verification delay
A customer reports a verification delay. Record the request, check status through authorized systems, route exceptions to the designated team, and update the case.

## Mobile banking login issue
A customer cannot log in. Record the issue, follow the approved troubleshooting checklist, escalate security concerns, and document the status.
