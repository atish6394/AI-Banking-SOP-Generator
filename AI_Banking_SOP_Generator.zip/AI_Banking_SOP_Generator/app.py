import os
from datetime import date
import streamlit as st
from dotenv import load_dotenv
load_dotenv()
st.set_page_config(page_title="AI Banking SOP Generator", page_icon="📋")
st.title("📋 AI-Based Banking SOP & User Manual Generator")
st.caption("Portfolio prototype • Simulated examples • Not an official bank system")
with st.sidebar:
    st.header("Settings")
    mode=st.radio("Mode",["Demo mode (no API key)","AI mode (API key required)"])
    st.warning("Never enter real customer data, account numbers, OTPs, or confidential information.")
name=st.text_input("Process name", "UPI payment failure complaint")
audience=st.selectbox("Audience",["Customer support agent","Operations team","New employee"])
details=st.text_area("Process details", "A customer reports that money was debited but the beneficiary did not receive the payment. Record the complaint, verify transaction details through approved systems, follow the approved dispute/refund process, escalate when required, and update the case status.",height=130)
checklist=st.checkbox("Include verification checklist",True)
def demo(name,audience,details,checklist):
    steps=["Receive the request and record the case in the approved case-management system.","Confirm required information using approved internal procedures.","Review case details and status in authorized systems.","Follow the organization's approved procedure; do not promise an outcome before verification.","Escalate unresolved or unusual cases to the designated team.","Record actions taken and update the case status.","Close the case only when approved closure criteria are met."]
    s=f"# Standard Operating Procedure: {name}\n\n**Audience:** {audience}\n**Created:** {date.today().isoformat()}\n**Status:** Draft — requires review and approval\n\n## 1. Purpose\nProvide a consistent approach for handling this process.\n\n## 2. Process details supplied\n{details}\n\n## 3. Procedure\n"
    s+="\n".join(f"{i}. {v}" for i,v in enumerate(steps,1))
    s+="\n\n## 4. Roles\n- Case handler: record information and document actions.\n- Process owner: review exceptions and approve decisions where required.\n\n## 5. Escalation\n- Escalate cases that cannot be resolved using the approved process.\n- Confirm applicable targets and escalation paths with the process owner.\n"
    if checklist: s+="\n## 6. Verification checklist\n- [ ] Case recorded\n- [ ] Information checked through authorized systems\n- [ ] Approved procedure followed\n- [ ] Escalation completed if required\n- [ ] Actions and status documented\n- [ ] Draft reviewed by process owner\n"
    return s+"\n> Safety note: Generic simulated draft, not an official Axis Bank procedure. Validate before real-world use."
def ai_generate(name,audience,details,checklist):
    key=os.getenv("OPENAI_API_KEY","").strip()
    if not key: raise RuntimeError("OPENAI_API_KEY missing. Add it to .env or use Demo mode.")
    from openai import OpenAI
    client=OpenAI(api_key=key)
    prompt=f"Draft a generic learning-portfolio SOP, not an official bank procedure. Process: {name}. Audience: {audience}. Details: {details}. Include checklist: {checklist}. Use Purpose, Scope, Procedure, Roles, Escalation and Checklist if requested. Do not invent bank rules, regulatory requirements, or refund timelines; mark unknowns for process-owner confirmation. Label as draft requiring human review."
    r=client.responses.create(model=os.getenv("OPENAI_MODEL","gpt-4.1-mini"),input=prompt)
    return r.output_text
if st.button("✨ Generate SOP",type="primary"):
    try:
        st.session_state["sop"]=ai_generate(name,audience,details,checklist) if mode.startswith("AI") else demo(name,audience,details,checklist)
    except Exception as e: st.error(f"Generation failed: {e}")
if st.session_state.get("sop"):
    st.subheader("Generated SOP — review before use")
    st.warning("This is a draft. A qualified process owner must validate it before operational use.")
    st.markdown(st.session_state["sop"])
    safe="".join(c.lower() if c.isalnum() else "_" for c in name).strip("_") or "sop"
    st.download_button("Download Markdown",st.session_state["sop"],file_name=f"{safe}_draft.md",mime="text/markdown")
    st.download_button("Download text",st.session_state["sop"],file_name=f"{safe}_draft.txt",mime="text/plain")
