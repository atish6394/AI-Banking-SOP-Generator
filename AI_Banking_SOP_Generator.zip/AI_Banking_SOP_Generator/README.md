# AI-Based Banking SOP & User Manual Generator

A Streamlit portfolio prototype that creates structured draft SOPs from a process description.

## Features
- Demo mode works without an API key
- Optional AI mode using the OpenAI API
- Structured steps and optional checklist
- Download as Markdown or text
- Human-review and simulated-data warnings

## Run locally
1. Install Python 3.10+.
2. Extract the ZIP and open a terminal in this folder.
3. Create a virtual environment (recommended): `python -m venv .venv`
4. Activate it: Windows `.venv\\Scripts\\activate`; macOS/Linux `source .venv/bin/activate`
5. Install: `pip install -r requirements.txt`
6. Run: `streamlit run app.py`
7. Open the local URL Streamlit prints (usually `http://localhost:8501`).

## Optional AI mode
Copy `.env.example` to `.env`, add your own API key, and restart. API usage may cost money. Never commit `.env` or expose your key on GitHub. Demo mode needs no key.

## Safety
Independent learning project, not affiliated with Axis Bank. Use fictional examples only. Do not enter real customer data or confidential information. Generated content is not official banking policy and must be validated by a process owner before use.

## Demo input
Process: UPI payment failure complaint
Audience: Customer support agent
Details: A customer reports a payment failure. Record the complaint, verify transaction details in authorized systems, follow approved procedures, escalate exceptions, and update the case.
